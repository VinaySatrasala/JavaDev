package com.RelationsJpa.DemoRelations;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoRelationsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoRelationsApplication.class, args);
	}

}
