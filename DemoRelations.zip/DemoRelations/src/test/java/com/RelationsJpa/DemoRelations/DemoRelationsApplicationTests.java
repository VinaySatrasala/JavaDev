package com.RelationsJpa.DemoRelations;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoRelationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
